const formComments = document.querySelector("#comments")
console.log(formComments)


formComments.addEventListener("submit", function(evento){
    console.log(evento)
})